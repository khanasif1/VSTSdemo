<html>
 <head>
  <title>Azure + PHP</title>
 </head>
 <body>
 <?php echo '<p>VSTS + AZURE Loves php </p>'; ?> 
 <img src="https://i0.wp.com/hajekj.net/wp-content/uploads/2017/04/php.jpg?w=1000&ssl=1" />
 </body>
</html>